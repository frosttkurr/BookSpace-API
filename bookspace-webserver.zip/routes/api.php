<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::prefix('buku')->group(function(){
    Route::get('/', 'BukuController@getAllBuku');
    Route::get('edukasi', 'BukuController@getBukuEdukasi');
    Route::get('ilmiah', 'BukuController@getBukuIlmiah');
    Route::get('fiksi', 'BukuController@getBukuFiksi');
    Route::get('sejarah', 'BukuController@getBukuSejarah');
    Route::get('bisnis', 'BukuController@getBukuBisnis');
    Route::get('novel', 'BukuController@getBukuNovel');
    Route::get('majalah', 'BukuController@getBukuMajalah');
    Route::post('/tambah', 'BukuController@insertBuku');
    Route::put('/update/{id}', 'BukuController@updateBuku');
    Route::delete('/delete/{id}', 'BukuController@deleteBuku');
});

Route::prefix('pinjam')->group(function(){
    Route::get('/', 'PinjamController@getAllPinjam');
    Route::get('/{id}', 'PinjamController@getDetailPinjam');
    Route::post('/tambah', 'PinjamController@insertPinjam');
    Route::put('/update/{id}', 'PinjamController@updatePinjam');
    Route::put('/return/{id}', 'PinjamController@returnPinjam');
    Route::delete('/delete/{id}', 'PinjamController@deletePinjam');
});

Route::prefix('pengguna')->group(function(){
    Route::get('/{id}', 'PenggunaController@getPengguna');
    Route::get('/checkUser/{username}', 'PenggunaController@checkUsername');
    Route::get('/checkEmail/{email}', 'PenggunaController@checkEmail');
    Route::get('/checkUserPass/{userpass}', 'PenggunaController@checkUsernameAndPassword');
    Route::post('/tambah', 'PenggunaController@insertPengguna');
    Route::put('/delete/{id}', 'PenggunaController@deletePengguna');
});